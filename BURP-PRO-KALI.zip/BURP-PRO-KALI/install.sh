#!/bin/bash
#code by kimak
clear
RED="$(printf '\033[31m')"
GREEN="$(printf '\033[32m')"
ORANGE="$(printf '\033[33m')"
BLUE="$(printf '\033[34m')"
MAGENTA="$(printf '\033[35m')"
CYAN="$(printf '\033[36m')"
WHITE="$(printf '\033[37m')"
BLACK="$(printf '\033[30m')"
BLACKBG="$(printf '\033[40m')"
RESETFG="$(printf '\e033[0m')"
RESETBG="$(printf '\e[0m\n')"
YELLOW="$(printf '\e[1;33m')"

path=(pwd)

if [ -f /usr/local/bin/burpsuite ]; then
    printf "	\033[31;1m[\033[32;1mOK\033[31;1m]\033[37;1m Burp Suite Is ${GREEN}Installed.\n"
    else
    printf "	\033[37;1m[\033[31;1m!\033[37;1m]\033[37;1m Installing Burp Suite Professional . . . File Size [503mb]!\n"
    Link="https://portswigger-cdn.net/burp/releases/download?product=pro&version=&type=jar"
    wget "$Link" -O burp_suite_pro.jar --quiet --show-progress
    sleep 1
    printf "	\033[31;1m[\033[32;1mOK\033[31;1m]\033[37;1m Download Finish . . . ${GREEN}success.\n"
    sleep 0.025


    # execute Keygenerator
    printf "	\033[31;1m[\033[32;1m*\033[31;1m]\033[37;1m Start Key . . .\n"
    (java -jar keygen.jar) &
    sleep 1
    
    # Execute Burp Suite Professional with Keyloader
    printf "	\033[31;1m[\033[32;1m*\033[31;1m]\033[37;1m Executing Burp Suite Professional with Keyloader . . .${GREEN}\n"
    echo "java --illegal-access=permit -Dfile.encoding=utf-8 -javaagent:$path/loader.jar -noverify -jar $path/burp_suite_pro.jar &" > burpsuite
    chmod +x burpsuite
    cp -r burpsuite /usr/local/bin
    sleep 1
    
    
    #clear file
    if [ -f $path/burp_suite_pro.jar ]; then
	    echo ''
	    printf "	\033[31;1m[\033[32;1m*\033[31;1m]\033[37;1m remove . . burp_suite_pro.jar\n"
	    rm -fr burp_suite_pro.jar
	    else
	    sleep 1
	    printf "	\033[31;1m[\033[32;1mOK\033[31;1m]\033[37;1m removing . . . ${GREEN}success.\n"
	    sleep 0.025
    fi
    
    if [ -f $path/burpsuite ]; then
	    echo ''
	    printf "	\033[31;1m[\033[32;1m*\033[31;1m]\033[37;1m remove . . burpsuite\n"
	    rm -fr burpsuite
	    else
	    sleep 1
	    printf "	\033[31;1m[\033[32;1mOK\033[31;1m]\033[37;1m removing . . . ${GREEN}success.\n"
	    sleep 0.025
    fi
    
    printf "	\033[31;1m[\033[32;1m*\033[31;1m]\033[37;1m for run type burpsuit"
    sleep 5
    exit
    
    
else
    printf "	\033[37;1m[\033[31;1m!\033[37;1m]\033[37;1m Run As Root!\n"
    exit
fi

